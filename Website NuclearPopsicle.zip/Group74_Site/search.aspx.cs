﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class search : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string terms = Request["search"];
        string title;
        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        DataTable results = new DataTable(); /* making a object of Datatable*/
        using (OleDbConnection conn = new OleDbConnection(connString))
        {
           
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM musics WHERE title LIKE '%"+terms+"%' ",conn);
            conn.Open(); /*Opening connection to database*/
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
            adapter.Fill(results); /*filling the DataTable with executed query*/
            if (results.Rows.Count !=0) /*if a row is returned then do somthing*/
            {            
                    using (OleDbDataReader reader = cmd.ExecuteReader())/*getting all rows where username = username txbox and password = pass txtbox*/
                    {
                        while (reader.Read()) /*putting them in to a array*/
                        {
                      
                            title = reader[1].ToString();/*getting out the id*/
                                                         //searchimg.Attributes["src"] = "music\\music_img\\" + terms + ".png";
                        searchbox.InnerHtml += "<a style='text-decoration:none; color:white;font-weight:bolder;'  target='_blank' href ='musicplayer.aspx?musicname=" + title + "'><img class='circle-avatarsearch' height='50px' width='50px' src=\"music\\music_img\\" + title + ".png\"/>" + "  " + title + "</a><div style='padding:4px;'></div>";
                        }
                    }
            }
         else
            {
                searchbox.InnerHtml = "<a href ='#'><img class='circle-avatarsearch' height='50px' width='50px' src=\"music\\music_img\\" + "nofound" + ".png\"/></a>" + "  " + "No Result Found";
             
            }
            
        }
    }
}