﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class deleteEvent : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string deleteid = Request["deleteId"];//event
        string deletemusic = Request["deletemusic"];//music
        string deletelatest = Request["deletelatest"];//Latest News
        string deletetrending = Request["deletetrending"];//Trending News

        if (deleteid != null)
        {
            int _deleteid = Request["deleteId"] == null ? 0 : Convert.ToInt32(Request["deleteId"]); //Varible

            OleDbConnection connect = new OleDbConnection(); //Creating a db object            
            connect.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            connect.Open();
            OleDbCommand cmd = new OleDbCommand("DELETE FROM [events] WHERE [event_id]="+ _deleteid, connect);
            cmd.ExecuteNonQuery();
          
            connect.Close();
            Response.Redirect("adminpages.aspx");
        }
        /*------------------------MUSIC--------------------*/
        if (deletemusic != null)
        {
            int _deleteid = Request["deletemusic"] == null ? 0 : Convert.ToInt32(Request["deletemusic"]); //Varible

            OleDbConnection connect = new OleDbConnection(); //Creating a db object            
            connect.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            connect.Open();
            OleDbCommand cmd = new OleDbCommand("DELETE FROM [musics] WHERE [musicid]=" + _deleteid, connect);
            cmd.ExecuteNonQuery();

            connect.Close();
            Response.Redirect("adminpages.aspx");
        }
        /*------------------------LATEST NEWS--------------------*/
        if (deletelatest != null)
        {
            int _deleteid = Request["deletelatest"] == null ? 0 : Convert.ToInt32(Request["deletelatest"]); //Varible

            OleDbConnection connect = new OleDbConnection(); //Creating a db object            
            connect.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            connect.Open();
            OleDbCommand cmd = new OleDbCommand("DELETE FROM [news] WHERE [ID]=" + _deleteid, connect);
            cmd.ExecuteNonQuery();

            connect.Close();
            Response.Redirect("adminpages.aspx");
        }

        /*------------------------TRENDING NEWS--------------------*/
        if (deletetrending != null)
        {
            int _deleteid = Request["deletetrending"] == null ? 0 : Convert.ToInt32(Request["deletetrending"]); //Varible

            OleDbConnection connect = new OleDbConnection(); //Creating a db object            
            connect.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            connect.Open();
            OleDbCommand cmd = new OleDbCommand("DELETE FROM [news] WHERE [ID]=" + _deleteid, connect);
            cmd.ExecuteNonQuery();

            connect.Close();
            Response.Redirect("adminpages.aspx");
        }

    }
}