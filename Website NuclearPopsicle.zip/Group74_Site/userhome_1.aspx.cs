﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
    string Dbid, DbUserId, DbUsername, DbPost;
    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["USER_ID"] == null)
        {
            Response.Redirect("~/Default.aspx");
        }
        int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]); //Varible
     
        OleDbConnection _conn = new OleDbConnection(connString);
        OleDbDataAdapter sda = new OleDbDataAdapter("SELECT * FROM discussion ORDER BY discussion_id DESC", _conn);
        DataTable dt = new DataTable();
        sda.Fill(dt);
        Repeater1.DataSource = dt;
        Repeater1.DataBind();

    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        DataTable results = new DataTable();

        using (OleDbConnection conn = new OleDbConnection(connString))
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM discussion", conn);
            conn.Open();

            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(results);
            if (results.Rows.Count != 0)
            {
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Dbid = reader[0].ToString();
                        DbUserId = reader[1].ToString();
                        DbUsername = reader[2].ToString();
                        DbPost = reader[3].ToString();
                        //userpic.Attributes["src"] = "users\\" + DBusername + "\\" + DBusername + ".png";
                        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
                        {
                            
                           
                        }
                    }
                }

            }
        }

      

    }
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        //ON CLICK
        if (e.CommandName == "reply_view")
        {
        //    Response.Redirect("~/userhome.aspx?discusion='"+ Dbid + "'");
        //    HyperLink link = (HyperLink)e.Item.FindControl("reply_view");
        //    link.Attributes["src"] = "userhome.aspx?discusion='" + Dbid + "'";

        }

     }


}