﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    string DBusername, DBuserpic;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USER_ID"] == null)
        {
            Response.Redirect("~/login.aspx");
        }

    string discussionID = Request["discussionID"];
       if(discussionID ==null)
        {
            Response.Redirect("~/login.aspx");
        }
        
        int _discussionID = Request["discussionID"] == null ? 0 : Convert.ToInt32(Request["discussionID"]);
        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        ///*^^location of database*/
        OleDbConnection conn = new OleDbConnection(connString);

        OleDbDataAdapter sda = new OleDbDataAdapter("SELECT * FROM discussion WHERE [discussion_id] ="+ _discussionID, conn);

        DataTable dt = new DataTable();
        sda.Fill(dt);
        Repeater1.DataSource = dt;
        Repeater1.DataBind();
        /*------------------------*/
        /*REPATER 2*/
                
        OleDbDataAdapter sda2 = new OleDbDataAdapter("SELECT * FROM comments WHERE [discussion_id] =" + _discussionID + " ORDER BY comment_id DESC", conn);
         
        DataTable dt2 = new DataTable();
        sda2.Fill(dt2);
        Repeater2.DataSource = dt2;
        Repeater2.DataBind();
        /*----------------------------------*/

        int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]);
        DataTable results = new DataTable();
        using (OleDbConnection conn2 = new OleDbConnection(connString))
        {

            OleDbCommand cmd = new OleDbCommand("SELECT * FROM users WHERE[id] = " + Session_ID , conn2);

            conn2.Open(); /*Opening connection to database*/
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
            adapter.Fill(results); /*filling the DataTable with executed query*/
            if (results.Rows.Count != 0) /*if a row is returned then do somthing*/
            {
                using (OleDbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read()) /*putting them in to a array*/
                    {
                        DBusername = reader[1].ToString();
                        DBuserpic = reader[5].ToString();

                        submitimage.Attributes["src"] = reader[5].ToString();/*getting out the id*/
                                                          //lblError.Text = DBid.ToString();
                    }
                }
            }
        }
        /*-------------------------------------*/
     
  
    }


   
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        if (commentText.Text != "")
        {
            int _discussionID = Request["discussionID"] == null ? 0 : Convert.ToInt32(Request["discussionID"]);
            int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]);
            string time = DateTime.Now.ToShortTimeString();
            time = time.ToString();
            string date = DateTime.Now.ToShortDateString();
            string datetime = date + " " + time;

            OleDbConnection con = new OleDbConnection(); //Creating a db object
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";

            cmd.Connection = con;

            string sql =
           "INSERT INTO comments (discussion_id,userid,username,user_pic,comment,[time_date]) VALUES('" + _discussionID + "','" + Session_ID + "','" + DBusername + "','" + DBuserpic + "','" + commentText.Text + "','"+ datetime + "')";

            try
            {
                con.Open();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                con.Close();

                Label2.ForeColor = System.Drawing.Color.Green;
                Label2.Text = "Comment Posted";
                Response.Redirect(Request.RawUrl);
            }
            catch (Exception ex)
            {
                Label2.Text = ex.ToString();
                con.Close();
            }

        }
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {


    }
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    /*End of Repeater one */
    protected void Repeater2_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {


    }
    protected void Repeater2_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

}
