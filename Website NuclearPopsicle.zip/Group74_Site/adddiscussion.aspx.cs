﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
   

    string DBid, DBusername, DBname, DBemail, DBuser_pic,datetime;
    protected void Page_Load(object sender, EventArgs e)
    {

        
        int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]);
        if (Session["USER_ID"] ==null)
        {
            Response.Redirect("~/login.aspx");
        }
        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        using (OleDbConnection conn = new OleDbConnection(connString))
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM users WHERE [id] = " + Session_ID, conn);
            DataTable results = new DataTable();
            conn.Open(); /*Opening connection to database*/

            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
            adapter.Fill(results); /*filling the DataTable with executed query*/
            if (results.Rows.Count != 0) /*if a row is returned then do somthing*/
            {
                using (OleDbDataReader reader = cmd.ExecuteReader())/*getting all rows where username = username txbox and password = pass txtbox*/
                {
                    while (reader.Read()) /*putting them in to a array*/
                    {
                        DBid = reader[0].ToString();/*getting out the id*/
                        DBusername = reader[1].ToString();
                        DBname = reader[3].ToString();
                        DBemail = reader[4].ToString();
                        DBuser_pic = reader[5].ToString();
                    }
                }
            }
          

        }
        
    }
    
    protected void btnsub_Click(object sender, EventArgs e)
    {
        
        string discussion_text = txtdiscussion.Text;
        if (discussion_text !=null)
        {
            string time = DateTime.Now.ToShortTimeString();
            time = time.ToString();
            string date = DateTime.Now.ToShortDateString();
            string datetime = date + " " + time;

            OleDbConnection con = new OleDbConnection(); //Creating a db object
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            
            cmd.Connection = con;
            
            string sql =
           "INSERT INTO discussion (user_id,username,user_post,user_pic,[datetime]) VALUES ('" + Convert.ToInt32(DBid) + "','" + DBusername + "','" + discussion_text + "','" + DBuser_pic + "','"+datetime+"')";
            try
            {
                con.Open();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                con.Close();
                Response.Redirect("~/userhome_1.aspx");
            }
            catch (Exception ex)
            {
                //Label1.Text = ex.ToString();
                con.Close();
            }

        }
    }
}