﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public partial class Default2 : System.Web.UI.Page
{
		/*-------------START ----------FUCNTION TO CREATE HASED PASSWORD--------------START-------*/

    /*-------------START ----------MD55 TO CREATE HASED PASSWORD--------------START-------*/
    public string Getmd5(string text)
    {
        MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
        md5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(text));
        byte[] result = md5.Hash;
        StringBuilder str = new StringBuilder();
        for (int i = 1; i < result.Length; i++)
        {
            str.Append(result[i].ToString("x2"));
        }
        return str.ToString();
    }
    /*-------------ENDDDDD ----------MD55 TO CREATE HASED PASSWORD--------------START-------*/
	/*public String CreateSalt(int size)
	{
		var rng = new System.Security.Cryptography.RNGCryptoServiceProvider();
		var buff = new byte[size];
		rng.GetBytes(buff);

		return Convert.ToBase64String(buff);
		
        //NOT USING
	}

	public String GenerateSHA256Hash(String input, String salt)
	{
		byte[] bytes = System.Text.Encoding.UTF8.GetBytes(input + salt);
		System.Security.Cryptography.SHA256Managed sha256hashstring = 
		new System.Security.Cryptography.SHA256Managed();
		byte[] hash = sha256hashstring.ComputeHash(bytes);
        //NOT USING
		return Convert.ToBase64String(hash);
	} */
	/*-----------------------END END -- FUCNTION TO CREATE HASED PASSWORD------------END ---------*/
  
    protected void btsignup_Click(object sender, EventArgs e)
    {
        OleDbConnection con = new OleDbConnection(); //Creating a db object
        OleDbCommand cmd = new OleDbCommand();
       
        con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        cmd.Connection = con;
		
		 // to prevent Sql Injections 
        cmd.Parameters.AddWithValue("@userName", tbUname.Text.Trim());
        //cmd.Parameters.AddWithValue("@password", tbPass.Text.Trim());
        cmd.Parameters.AddWithValue("@Name", tbName.Text.Trim());
        cmd.Parameters.AddWithValue("@Email", tbEmail.Text.Trim());
		
		//string salt = CreateSalt(10); //give a size of 10 for hasing password
        string hashpasword = Getmd5(tbPass.Text);  //GenerateSHA256Hash(tbPass.Text,salt); //getting thr password and hasing it over here
                                                   //lblreport.Text = hashpasword; //display the hased password

        string folderPath = Server.MapPath("~/users/" + tbUname.Text);
        string source = Server.MapPath("~/users/defualtuserpic.png");
        //Check whether Directory (Folder) exists.

       string locationofuserpic = "users\\" + tbUname.Text + "\\" + tbUname.Text + ".png";
        string sql =
           "INSERT INTO users (username, [password],name,email,user_pic) VALUES (@userName,'"+hashpasword+"', @Name, @Email,'"+ locationofuserpic + "')";

        try
        {
			con.Open();
            cmd.CommandText = sql;
            cmd.ExecuteNonQuery();
            con.Close();

            if (!Directory.Exists(folderPath))
            {
                //If Directory (Folder) does not exists. Create it.
                Directory.CreateDirectory(folderPath);
                string folderPath2 = Server.MapPath("~/users/" + tbUname.Text + "/");
                File.Copy(source, folderPath2 + tbUname.Text + ".png", true); //copying the default picture
            }



            string labelFromDatabase = "Success, Please <a href=\"{0}\"> Login </a>";
            string url = "login.aspx";
            btsignup.Enabled = false;
            lblreport.Text = String.Format(labelFromDatabase, url);
            //lblreport.Text = "Success, Please Login";
        }
        catch (Exception ex)
        {
            lblreport.Text = ex.ToString();
            con.Close();
        }
    }
}