﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string news_trending = "news_trending";
        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        ///*^^location of database*/
        
        OleDbConnection conn = new OleDbConnection(connString);
        OleDbDataAdapter sda = new OleDbDataAdapter("SELECT * FROM news WHERE news_type='"+ news_trending + "' ORDER BY ID DESC ", conn);

        DataTable dt = new DataTable();
        sda.Fill(dt);
        Repeater1.DataSource = dt;
        Repeater1.DataBind();
    }
}