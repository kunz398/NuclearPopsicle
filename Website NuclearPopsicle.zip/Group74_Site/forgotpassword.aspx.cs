﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    string DBid, DBusername, DBemail;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btPassRec_Click(object sender, EventArgs e)
    {
        string entered_username = txtusername.Text;
        string entered_email = txtemail.Text;
     
        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        DataTable results = new DataTable();



        using (OleDbConnection conn = new OleDbConnection(connString))
        {
            OleDbCommand cmd = new OleDbCommand("SELECT * FROM users WHERE username = '" + entered_username + "' AND email= '" + entered_email + "'", conn);
            conn.Open(); /*Opening connection to database*/

            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
            adapter.Fill(results); /*filling the DataTable with executed query*/
            if (results.Rows.Count != 0) /*if a row is returned then do somthing*/
            {
                using (OleDbDataReader reader = cmd.ExecuteReader())/*getting all rows where username = username txbox and password = pass txtbox*/
                {
                    while (reader.Read()) /*putting them in to a array*/
                    {
                        DBid = reader[0].ToString();/*getting out the id*/
                        DBusername = reader[1].ToString();
                        DBemail = reader[4].ToString();
                        //lblError.Text = DBid.ToString();
                    }
                    if (DBusername == entered_username && DBemail == entered_email)
                    {
                        //random gen
                        Random rnd = new Random();
                        int recovery_code = rnd.Next(10000,99999);

                     

                        MailMessage mailMessage = new MailMessage("nuclearpopsicle2017@gmail.com", "nuclearpopsicle2017@gmail.com");
                        mailMessage.Subject = "RESET PASSWORD: "+ DBusername ;
                        mailMessage.Body = "Name:  " + DBusername + "\n" +
                                           "Email:  " + DBemail + "\n" +
                                           "UserId:  " + DBid + "\n" +
                                           "Ticket Number: " + recovery_code + "\n";

                        SmtpClient smptClient = new SmtpClient("smtp.gmail.com", 587);
                        smptClient.Credentials = new System.Net.NetworkCredential()
                        {
                            UserName = "nuclearpopsicle2017@gmail.com",
                            Password = "_nuclearpopsicle2017"
                        };

                        smptClient.EnableSsl = true;
                        smptClient.Send(mailMessage);

                        lblError.Visible = true;
                        lblError.ForeColor = System.Drawing.Color.Green;
                        lblError.Text = "Your Request has been put in a queue Your Ticket Number is: " + recovery_code.ToString() + "\n:You should Recive your Password in the next 24 Hours.";

                        // Response.Redirect("~/forgotpassword_2.aspx");
                    } 
                    else
                    {
                        lblError.Visible = true;
                        lblError.ForeColor = System.Drawing.Color.Red;
                        lblError.Text = "Incorrect Username or Email, Please Try Again";
                    }
                }
             ;
            }
            else
            {
                lblError.Visible = true;
                lblError.ForeColor = System.Drawing.Color.Red;
                lblError.Text = "Incorrect Username or Email, Please Try Again";
            }
        }
    }
}