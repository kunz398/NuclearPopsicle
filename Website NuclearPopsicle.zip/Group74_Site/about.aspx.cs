﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class Default2 : System.Web.UI.Page
{
    protected void btsubmit_Click(object sender, EventArgs e)
    {
        string namesender = name.Text;
        string emailsender = email.Text;
        string message = commenting.Text;
        if (namesender != "" && emailsender !="" && message != "")
        { 
            MailMessage mailMessage = new MailMessage("nuclearpopsicle2017@gmail.com", "nuclearpopsicle2017@gmail.com");
            mailMessage.Subject = "Feedback";
            mailMessage.Body = "Name:  " + namesender + "\n" +
                               "Email:  " + emailsender + "\n" +
                               "Feedbacks:  " + message + "\n";

            SmtpClient smptClient = new SmtpClient("smtp.gmail.com", 587);
            smptClient.Credentials = new System.Net.NetworkCredential()
            {
                UserName = "nuclearpopsicle2017@gmail.com",
                Password = "_nuclearpopsicle2017"
            };

            smptClient.EnableSsl = true;
            smptClient.Send(mailMessage);
            lblresult.ForeColor = System.Drawing.Color.Green;
            lblresult.Text = "Your Feedback has been sent.";
            
        }
        else
        {
            lblresult.ForeColor = System.Drawing.Color.Red;
            lblresult.Text = "Please Fill in all the Requred Fields";
                        
        }
    }


  
}

