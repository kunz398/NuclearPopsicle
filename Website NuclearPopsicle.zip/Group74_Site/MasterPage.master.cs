﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;

public partial class MasterPage : System.Web.UI.MasterPage
{
    string DBusername;
    protected void Page_Load(object sender, EventArgs e)
    {
		 int _session = Convert.ToInt32(Session["USER_ID"]);

        if (Session["USER_ID"] == null)
        {
           btn_login.Visible = true;
            btn_logout.Visible = false;
           adminaccess.Visible = false;
            discussion.Visible = false;
           
        }
        else
        {
            adminaccess.Visible = false;
            btn_login.Visible = false;
            btn_logout.Visible = true;
            discussion.Visible = true;

            if (_session == 10){
				adminaccess.Visible = true;
				
			}
            int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]);

            string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            /*^^location of database*/
            DataTable results = new DataTable(); /* making a object of Datatable*/

            using (OleDbConnection conn = new OleDbConnection(connString))
            {

                OleDbCommand cmd = new OleDbCommand("SELECT * FROM users WHERE [id] = " + Session_ID, conn);
                conn.Open(); /*Opening connection to database*/
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
                adapter.Fill(results); /*filling the DataTable with executed query*/
                if (results.Rows.Count != 0) /*if a row is returned then do somthing*/
                {
                    using (OleDbDataReader reader = cmd.ExecuteReader())/*getting all rows where username = username txbox and password = pass txtbox*/
                    {
                        while (reader.Read()) /*putting them in to a array*/
                        {
                            DBusername = reader[1].ToString();/*getting out the id*/
                            userpic.Attributes["src"] = "users\\" + DBusername + "\\" + DBusername + ".png";
                            //lblError.Text = DBid.ToString();
                        }
                    }
                    lblacc_username.Text = DBusername.ToString(); 
                }
            }
          
            //lblSuccess.Text = "Login Success, Welcome " + DBusername.ToString() + " ";
        }
    }

    protected void btnSignOut_Click(object sender, EventArgs e)
    {
        Session["USER_ID"] = null;
        Response.Cookies.Clear();
        Response.Redirect("~/login.aspx");
    }
}
