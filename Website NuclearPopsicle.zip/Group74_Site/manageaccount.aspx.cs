﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.IO;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
    string DBusername;

    protected void Page_Load(object sender, EventArgs e)
    {
        /* THIS CODE FETCHES THE USERNAME WITH ACRODANCE TO THE USER ID WHICH IS THE PRIMARY KEY*/
        if (Session["USER_ID"] == null)
        {
            Response.Redirect("~/Default.aspx");
        }
        else
        {
         int Session_ID = Session["USER_ID"] == null ? 0 : Convert.ToInt32(Session["USER_ID"]);

            string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            /*^^location of database*/
            DataTable results = new DataTable(); /* making a object of Datatable*/

            using (OleDbConnection conn = new OleDbConnection(connString))
            {

                OleDbCommand cmd = new OleDbCommand("SELECT * FROM users WHERE [id] = " + Session_ID, conn);
                conn.Open(); /*Opening connection to database*/
                OleDbDataAdapter adapter = new OleDbDataAdapter(cmd); /*executing the query*/
                adapter.Fill(results); /*filling the DataTable with executed query*/
                if (results.Rows.Count != 0) /*if a row is returned then do somthing*/
                {
                    using (OleDbDataReader reader = cmd.ExecuteReader())/*getting all rows where username = username txbox and password = pass txtbox*/
                    {
                        while (reader.Read()) /*putting them in to a array*/
                        {
                            DBusername = reader[1].ToString();/*getting out the id*/
                            //lblError.Text = DBid.ToString();
                        }
                    }
                }
            }
             
            //lblSuccess.Text = "Login Success, Welcome " + DBusername.ToString() + " ";
            }
        }

    protected void btnadddp_Click(object sender, EventArgs e)
    {
        if (uploaduser.HasFile) /*ADDING JPG STARTS here */
        {
            string uploadFolder1 = Request.PhysicalApplicationPath + "\\users\\" + DBusername + "\\";
            string extension1 = Path.GetExtension(uploaduser.PostedFile.FileName);
            extension1 = ".png";
            if (extension1.ToLower() != ".png")
            {
                lblreport.Text = "Please Upload a valid image file";
            }
            else
            {
                //destination name and extension
                uploaduser.SaveAs(uploadFolder1 + DBusername + extension1);
                lblreport.Text = "File uploaded successfully";
            }
        }
        else
        {
            lblreport.Text = "Please select a file.";
        } /*ADDING JPG ENDS here */
        /*---------------------------UPLOADING-------------------------*/
    }
}