﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;


public partial class _Default : System.Web.UI.Page

{  
	protected void Page_Load(object sender, EventArgs e)
		{
			 
			
       OleDbConnection connection = new OleDbConnection(); //Creating a db object
	   connection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
  
			 try{
			 	 connection.Open();
				 OleDbCommand command = new OleDbCommand();
				 command.Connection = connection; 
				 string query ="Select date,concert_name,venue,normal_price,vip_price  From events";
				 command.CommandText = query;

				 OleDbDataAdapter da = new OleDbDataAdapter(command);
				 DataTable dt = new DataTable();
				 da.Fill(dt);
				 GridView1.DataBind();
				 GridView1.DataSource = dt;
				 GridView1.DataBind();
				 GridView1.HeaderRow.Cells[0].Text="Date";
				 GridView1.HeaderRow.Cells[1].Text="Concert Name";
				 GridView1.HeaderRow.Cells[2].Text="Venue";
				 GridView1.HeaderRow.Cells[3].Text="Ticket Price";
				 GridView1.HeaderRow.Cells[4].Text="VIP Price";

			 }
			 catch(Exception ex)
			 {
		
			 	 //error
			 }

		}

}
