﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.IO;
using System.Data;

public partial class Default2 : System.Web.UI.Page
{
  string extension_for_image, extension_for_latest, extension_for_trending;
  string extension_for_music;
	protected void btnaddevent_Click(object sender, EventArgs e)
	{
        if (txtdate.Text != "" && txtconcertname.Text != "" && txtvenue.Text != "" && txtnormalprice.Text != "" && txtvipprice.Text != "")
        {
            if (Page.IsValid)
            {


                OleDbConnection con = new OleDbConnection(); //Creating a db object
                OleDbCommand cmd = new OleDbCommand();
                con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
                cmd.Connection = con;

                string sql =
                    "INSERT INTO events ([date], [concert_name],[venue],[normal_price],[vip_price]) VALUES ('" + txtdate.Text + "','" + txtconcertname.Text + "','" + txtvenue.Text + "','" + txtnormalprice.Text + "','" + txtvipprice.Text + "')";

                try
                {
                    con.Open();
                    cmd.CommandText = sql;
                    cmd.ExecuteNonQuery();
                    con.Close();
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "Event Added";
                }
                catch (Exception ex)
                {
                    lbladminreport.Visible = true;
                    lbladminreport.ForeColor = System.Drawing.Color.Red;
                    lbladminreport.Text = "Event Could not be added please try again";
                    con.Close();
                }
            }
        }
        else
        {
            lbladminreport.Visible = true;
            lbladminreport.ForeColor = System.Drawing.Color.Red;
            lbladminreport.Text = "Event Could not be added please try again";
        }
    } //end of btnaddevent_Click/*----------------------------------------------------------------------*/

    protected void btnaddMusic_Click(object sender, EventArgs e)
	{
        if (txtmusictitle.Text != "" && txtdesc.Text != "" && txtartist.Text != "")
        {
            string uploadFolder = Request.PhysicalApplicationPath + "\\music\\music_mp3\\";
            string musictitleinput = txtmusictitle.Text;
            if (upmusicmp3.HasFile) /*ADDING MP3 STARTS here */
            {
                string extension = Path.GetExtension(upmusicmp3.PostedFile.FileName);
                extension_for_music = extension;
                if (extension.ToLower() != ".mp3")
                {
                    Label1.Text = "Please Upload a mp3 format file";
                }
                else
                {
                    upmusicmp3.SaveAs(uploadFolder + musictitleinput + extension);
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "File uploaded successfully as: " + musictitleinput + extension;
                    
                }
            }
            else
            {
                Label1.Text = "First select a file.";
            } /*ADDING MP3 ENDS here */
              /*----------------------------------------------------------------------*/

            if (upmusicimg.HasFile) /*ADDING JPG STARTS here */
            {
                string uploadFolder1 = Request.PhysicalApplicationPath + "\\music\\music_img\\";
                string extension1 = Path.GetExtension(upmusicimg.PostedFile.FileName);
                extension_for_image = extension1;
                extension1 = ".png";
                if (extension1.ToLower() != ".png")
                {
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "Please Upload a valid image file";
                }
                else
                {
                    upmusicimg.SaveAs(uploadFolder1 + musictitleinput + extension1);
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "File uploaded successfully";
                }
            }
            else
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = "First select a file.";
            } /*ADDING JPG ENDS here */
              /*---------------------------UPLOADING-------------------------*/
            extension_for_image = ".png"; //i think i can remove this but what the hell
            string imagesource = "music/music_img/" + musictitleinput + extension_for_image;
            string musicsource = "music/music_mp3/" + musictitleinput + extension_for_music;
            OleDbConnection con = new OleDbConnection(); //Creating a db object
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            cmd.Connection = con;

            string sql =
                "INSERT INTO musics ([title], [artist],[description],[image_src],[music_src]) VALUES ('" + txtmusictitle.Text + "','" + txtartist.Text + "','" + txtdesc.Text + "','" + imagesource + "','" + musicsource + "')";

            try
            {
                con.Open();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                con.Close();
                lbladminreport.Visible = true;
                lbladminreport.Text = "Music Added";
            }
            catch (Exception ex)
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = ex.ToString();
                con.Close();
            }
        }else
        {
            lbladminreport.Visible = true;
            lbladminreport.ForeColor = System.Drawing.Color.Red;
            lbladminreport.Text = "Music Could not be added please try again!";
        }
    }/*btnaddmusic ends here */


    /*@btnaddLatestNews_Click ADD LATEST NEWS STARTS*/
    protected void btnaddLatestNews_Click(object sender, EventArgs e) 
    {
        if (txtlatestnewspublishdate.Text != "" && txtlatestnewstitle.Text != "" && txtlatestnewstext.Text != "" && txtlatestwriter.Text != "")
        {
            if (UPLatestNewsImage.HasFile)
            {
                string uploadfolder = Request.PhysicalApplicationPath + "\\news\\";
                string _extention_latest = Path.GetExtension(UPLatestNewsImage.PostedFile.FileName);
                _extention_latest = ".png";
                if (_extention_latest.ToLower() != ".png")
                {
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "Please Upload a valid image file";
                }
                else
                {
                    UPLatestNewsImage.SaveAs(uploadfolder + txtlatestnewstitle.Text + _extention_latest);
                   
                }
            }
            else
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = "First select a file.";
            }

            string imagesource = "news\\" + txtlatestnewstitle.Text + ".png";

            OleDbConnection con = new OleDbConnection(); //Creating a db object
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            cmd.Connection = con;

            string sql =
                "INSERT INTO news ([news_type], [news_text],[news_title],[news_author],[news_picture]) VALUES ('news_latest','" + txtlatestnewstext.Text + "','" + txtlatestnewstitle.Text + "','" + txtlatestwriter.Text + "','" + imagesource + "')";

            try
            {
                con.Open();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                con.Close();
                lbladminreport.Visible = true;
                lbladminreport.Text = "Latest News Added";
            }
            catch (Exception ex)
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = ex.ToString();
                con.Close();
            }
        }
        else
        {
            lbladminreport.Visible = true;
            lbladminreport.ForeColor = System.Drawing.Color.Red;
            lbladminreport.Text = "Latest News not be added please try again!";
        }
}
     /*END OF LATEST NEWS*/

    protected void btnaddTrendingtNews_Click(object sender, EventArgs e) /*Start Of Trending News*/
    {
        if (txttrendingnewstitle.Text != "" && txttendingpublisheddate.Text != "" && txttrendnewstext.Text != "" && txttrendingwriter.Text != "")
        {
           if (UPtrendingnewsimage.HasFile)
            {
                string uploadfolder = Request.PhysicalApplicationPath + "\\news\\";
                string _extention_trending = Path.GetExtension(UPtrendingnewsimage.PostedFile.FileName);
                _extention_trending = ".png";
                if (_extention_trending.ToLower() != ".png")
                {
                    lbladminreport.Visible = true;
                    lbladminreport.Text = "Please Upload a valid image file";
                }
                else
                {
                    UPtrendingnewsimage.SaveAs(uploadfolder + txttrendingnewstitle.Text + _extention_trending);

                }
            }
            else
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = "First select a file.";
            }
            string imagesource = "news\\" + txttrendingnewstitle.Text + ".png";
                  
            OleDbConnection con = new OleDbConnection(); //Creating a db object
            OleDbCommand cmd = new OleDbCommand();
            con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            cmd.Connection = con;

            string sql =
                "INSERT INTO news ([news_type], [news_text],[news_title],[news_author],[news_picture]) VALUES ('news_trending','" + txttrendnewstext.Text + "','" + txttrendingnewstitle.Text + "','" + txttrendingwriter.Text + "','" + imagesource + "')";

            try
            {
                con.Open();
                cmd.CommandText = sql;
                cmd.ExecuteNonQuery();
                con.Close();
                lbladminreport.Visible = true;
                lbladminreport.Text = "Trending News Added";
            }
            catch (Exception ex)
            {
                lbladminreport.Visible = true;
                lbladminreport.Text = ex.ToString();
                con.Close();
            }
        }
        else
        {
            lbladminreport.Visible = true;
            lbladminreport.ForeColor = System.Drawing.Color.Red;
            lbladminreport.Text = "Trending News not be added please try again!";
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USER_ID"] == null)
        {
            Response.Redirect("~/login.aspx");
        }

        string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
        ///*^^location of database*/
        OleDbConnection conn = new OleDbConnection(connString);
        OleDbDataAdapter sda = new OleDbDataAdapter("SELECT * FROM events", conn);

        DataTable dt = new DataTable();
        sda.Fill(dt);
        Repeater1.DataSource = dt;
        Repeater1.DataBind();
        /*-----MUSIC------*/
        OleDbConnection conn2 = new OleDbConnection(connString);
        OleDbDataAdapter sda2 = new OleDbDataAdapter("SELECT * FROM musics", conn2);

        DataTable dt2 = new DataTable();
        sda2.Fill(dt2);
        Repeater2.DataSource = dt2;
        Repeater2.DataBind();
        /*LATEST*/
        string newstype_latest = "news_latest";
        OleDbConnection conn3 = new OleDbConnection(connString);
        OleDbDataAdapter sda3 = new OleDbDataAdapter("SELECT * FROM news WHERE [news_type]='"+ newstype_latest + "'", conn3);

        DataTable dt3 = new DataTable();
        sda3.Fill(dt3);
        Repeater3.DataSource = dt3;
        Repeater3.DataBind();

        /*TRENDING*/
        string newstype_trending = "news_trending";
        OleDbConnection conn4 = new OleDbConnection(connString);
        OleDbDataAdapter sda4 = new OleDbDataAdapter("SELECT * FROM news WHERE [news_type]='" + newstype_trending + "'", conn4);

        DataTable dt4 = new DataTable();
        sda4.Fill(dt4);
        Repeater4.DataSource = dt4;
        Repeater4.DataBind();

    }
    //protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    //{
    //}
    //protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
    //{

    //}
}
   
   

