﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using System.IO;

public partial class Default2_ : System.Web.UI.Page
{

    Boolean check = false;
    protected void Page_Load(object sender, EventArgs e)
    {
       
        if (!IsPostBack){
            string connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|nuclearpopsicledb.mdb";
            ///*^^location of database*/
            OleDbConnection conn = new OleDbConnection(connString);
            OleDbDataAdapter sda = new OleDbDataAdapter("SELECT * FROM musics", conn);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
          
      }
        check = true;
    }

    protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            Button btn = (Button)e.Item.FindControl("btnDownload");

            if (Session["USER_ID"] != null)
            {
                btn.Enabled = true;
            }
            else
            {
                btn.ToolTip = "You Would Need to Login to Download";
            }
        }

    }
    protected void Repeater1_ItemCommand(object source, RepeaterCommandEventArgs e)
        {

   

            if (e.CommandName == "DownloadMusic")
            {
                //To get title of music
                string Title = string.Empty;
                Label lbltitle = new Label();
                lbltitle = (Label)e.Item.FindControl("mediaheading");
                Title = lbltitle.Text;

                //to get path fo music
                string FilePath = string.Empty;
                Image imgfile = new Image();
                imgfile = (Image)e.Item.FindControl("dummymp3");
                FilePath = imgfile.ImageUrl;

                
                System.Web.HttpResponse response = System.Web.HttpContext.Current.Response;
                response.ClearContent();
                response.ContentType = "audio/mpeg";
                response.AddHeader("Content-Disposition", "attachment; filename=" + FilePath + ";");
                response.TransmitFile(FilePath);
                response.Flush();
                response.End();
            }
            else
            {
                //error
            }

   


    }
}